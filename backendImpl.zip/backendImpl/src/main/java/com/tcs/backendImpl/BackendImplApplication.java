package com.tcs.backendImpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendImplApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendImplApplication.class, args);
	}

}
