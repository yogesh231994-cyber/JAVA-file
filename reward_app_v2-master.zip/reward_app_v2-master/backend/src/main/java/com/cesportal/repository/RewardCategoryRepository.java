package com.cesportal.repository;

import com.cesportal.entity.RewardCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RewardCategoryRepository extends JpaRepository<RewardCategory, Long> {
}
